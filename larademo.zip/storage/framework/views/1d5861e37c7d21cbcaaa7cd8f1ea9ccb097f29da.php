<?php $__env->startSection('content'); ?>

<div class="container">
    <form method="GET" action="">
        <select name="statename">
                <option value="">Select State</option>
            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($state->statename); ?>' <?php echo e(Request::get('statename') ==$state->statename? 'selected="selected"' : ''); ?> > <?php echo e($state->statename); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="pincode">
                <option value="">Select Pincode</option>
            <?php $__currentLoopData = $pincodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pincode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($pincode->pincode); ?>' <?php echo e(Request::get('pincode') ==$pincode->pincode? 'selected="selected"' : ''); ?> > <?php echo e($pincode->pincode); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>


        <select name="districtname">
                <option value="">Select District</option>
            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($district->districtname); ?>' <?php echo e(Request::get('districtname') ==$district->districtname? 'selected="selected"' : ''); ?> > <?php echo e($district->districtname); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="divisionname">
                <option value="">Select Division</option>
            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($division->divisionname); ?>' <?php echo e(Request::get('divisionname') ==$division->divisionname? 'selected="selected"' : ''); ?> > <?php echo e($division->divisionname); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <input type="submit">
        <a href="<?php echo e(url('admin')); ?>">Clear</a>
    </form>
    <table class="table table-striped">
        <tr>
            <th>State
            <th>Pincode
            <th>District Name
            <th>Division Name
        </tr>
        <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($list->statename); ?></td>
                <td><?php echo e($list->pincode); ?></td>
                <td><?php echo e($list->districtname); ?></td>
                <td><?php echo e($list->divisionname); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
</div>

<?php echo e($lists->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\larademo\resources\views/list.blade.php ENDPATH**/ ?>