<?php $__env->startSection('content'); ?>
        <script>
            $(document).ready(function(){
                $.get('https://api.data.gov.in/resource/04cbe4b1-2f2b-4c39-a1d5-1c2e28bc0e32?api-key=579b464db66ec23bdd000001989e35b0bf294d227974a0dd1ff8df57&format=json', function(data, status){
                    console.log(data);
                })
            })
        </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\larademo\resources\views/data.blade.php ENDPATH**/ ?>